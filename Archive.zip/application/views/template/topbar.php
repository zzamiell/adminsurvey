 <!-- Content Wrapper -->
 <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

           <!-- Topbar -->
           <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow justify-content-center">
                <div class="text-gray-800">
                     <h1><?= $judul; ?></h1>
                </div>
                <!-- Sidebar Toggle (Topbar) -->
                <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                     <i class="fa fa-bars"></i>
                </button>

                <!-- Topbar Navbar -->
                <!-- <ul class="navbar-nav ml-auto">

                     <div class="topbar-divider d-none d-sm-block"></div>

                     <li class="nav-item dropdown no-arrow">
                          <a class="dropdown-item" href="http://localhost/sinarmulia/auth/logout" data-toggle="modal" data-target="#logoutModal">
                               <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                               Logout
                          </a>
                     </li>
                </ul> -->

           </nav>
           <!-- End of Topbar -->